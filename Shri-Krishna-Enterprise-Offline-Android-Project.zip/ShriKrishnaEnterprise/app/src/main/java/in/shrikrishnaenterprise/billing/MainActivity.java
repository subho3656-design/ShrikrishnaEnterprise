package in.shrikrishnaenterprise.billing;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.UUID;

public class MainActivity extends Activity {
    private DatabaseHelper db;
    private LinearLayout root, content;
    private String lastReceipt="";
    private BluetoothDevice selectedPrinter;
    private int paperWidth=58;
    private final ArrayList<Product> productData=new ArrayList<>();
    private static final int BT_PERMISSION=701;

    static class Product {
        long id; String name; double price,gst,stock;
        Product(long i,String n,double p,double g,double s){id=i;name=n;price=p;gst=g;stock=s;}
        @Override public String toString(){return name+"  |  ₹"+money(price)+"  |  Stock: "+qty(stock);}
    }

    @Override public void onCreate(Bundle state){super.onCreate(state);db=new DatabaseHelper(this);showDashboard();}

    private void shell(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(245,247,251));
        TextView brand=new TextView(this);brand.setText("SHRI KRISHNA ENTERPRISE");brand.setTextColor(Color.rgb(22,75,150));brand.setTextSize(20);brand.setTypeface(null,Typeface.BOLD);brand.setGravity(Gravity.CENTER);brand.setPadding(12,18,12,5);root.addView(brand);
        TextView sub=new TextView(this);sub.setText(title);sub.setTextColor(Color.DKGRAY);sub.setTextSize(14);sub.setGravity(Gravity.CENTER);sub.setPadding(8,0,8,14);root.addView(sub);
        LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setBackgroundColor(Color.WHITE);
        String[] tabs={"Home","Customers","Products","New Bill","Invoices","Printer"};
        for(String t:tabs){Button b=new Button(this);b.setText(t);b.setTextSize(10);b.setPadding(2,2,2,2);nav.addView(b,new LinearLayout.LayoutParams(0,52,1));b.setOnClickListener(v->navigate(t));}
        root.addView(nav);
        ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(16,14,16,24);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    private void navigate(String t){switch(t){case "Home":showDashboard();break;case "Customers":showCustomers();break;case "Products":showProducts();break;case "New Bill":showNewBill();break;case "Invoices":showInvoices();break;case "Printer":showPrinter();break;}}
    private TextView text(String s,int size,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.rgb(35,42,55));if(bold)v.setTypeface(null,Typeface.BOLD);v.setPadding(4,8,4,8);return v;}
    private EditText field(String hint,int inputType){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setInputType(inputType);e.setTextSize(16);content.addView(e);return e;}
    private Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setOnClickListener(v->action.run());content.addView(b);return b;}
    private void card(String s){TextView v=text(s,16,false);v.setBackgroundColor(Color.WHITE);v.setPadding(16,14,16,14);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,5);content.addView(v,p);}
    private void showDashboard(){shell("Offline billing and business management");card("TODAY'S / LIFETIME SALES\n₹ "+money(db.sales()));card("CUSTOMERS\n"+db.customerCount());card("PRODUCTS IN CATALOGUE\n"+db.productCount());card("All records are stored locally on this phone. No account or internet is required.");button("＋ CREATE NEW BILL",()->showNewBill());button("＋ ADD PRODUCT",()->showProducts());}

    private void showCustomers(){shell("Customer Management");content.addView(text("Add customer",18,true));EditText n=field("Customer name",1);EditText p=field("Mobile number",3);EditText a=field("Address",1);
        button("SAVE CUSTOMER",()->{String name=n.getText().toString().trim();if(name.isEmpty()){n.setError("Enter customer name");return;}long id=db.addCustomer(name,p.getText().toString().trim(),a.getText().toString().trim());if(id>0){toast("Customer saved offline");showCustomers();}else toast("Could not save customer");});
        content.addView(text("Saved customers",18,true));Cursor c=db.customers();while(c.moveToNext())card(c.getString(1)+"\n"+c.getString(2)+"\n"+c.getString(3));c.close();}

    private void showProducts(){shell("Product and Stock Management");content.addView(text("Add product",18,true));EditText n=field("Product name",1);EditText code=field("Product code / SKU (optional)",1);EditText price=field("Selling price (₹)",8194);EditText gst=field("GST percentage",8194);EditText stock=field("Opening stock / quantity",8194);
        button("SAVE PRODUCT",()->{try{String name=n.getText().toString().trim();if(name.isEmpty()){n.setError("Enter product name");return;}double pr=Double.parseDouble(price.getText().toString()),g=Double.parseDouble(gst.getText().toString()),q=Double.parseDouble(stock.getText().toString());if(pr<0||g<0||g>100||q<0)throw new NumberFormatException();long id=db.addProduct(name,code.getText().toString().trim(),pr,g,q);if(id>0){toast("Product saved offline");showProducts();}else toast("Could not save product");}catch(Exception ex){toast("Enter valid price, GST and stock");}});
        content.addView(text("Product catalogue / current stock",18,true));Cursor c=db.products();while(c.moveToNext())card(c.getString(1)+"\nCode: "+c.getString(2)+"\nSelling price: ₹"+money(c.getDouble(3))+" | GST: "+c.getDouble(4)+"%\nStock: "+qty(c.getDouble(5)));c.close();}

    private void loadProductData(){productData.clear();Cursor c=db.products();while(c.moveToNext())productData.add(new Product(c.getLong(0),c.getString(1),c.getDouble(3),c.getDouble(4),c.getDouble(5)));c.close();}
    private void showNewBill(){shell("Create New GST Bill");loadProductData();if(productData.isEmpty()){card("Add products first in the Products section before creating a bill.");button("GO TO PRODUCTS",()->showProducts());return;}
        EditText customer=field("Customer name",1);Spinner spinner=new Spinner(this);ArrayAdapter<Product> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,productData);spinner.setAdapter(adapter);content.addView(text("Select product",15,true));content.addView(spinner);
        EditText quantity=field("Quantity",8194);quantity.setText("1");TextView preview=text("",16,true);content.addView(preview);
        Runnable update=()->{Product p=(Product)spinner.getSelectedItem();double q=parse(quantity.getText().toString(),0);double base=p==null?0:p.price*q;double tax=base*(p==null?0:p.gst)/100.0;preview.setText("Available stock: "+(p==null?0:qty(p.stock))+"\nTaxable value: ₹"+money(base)+"\nGST: ₹"+money(tax)+"\nInvoice total: ₹"+money(base+tax));};
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){update.run();}public void onNothingSelected(android.widget.AdapterView<?> a){}});quantity.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){update.run();}public void afterTextChanged(android.text.Editable e){}});update.run();
        button("SAVE INVOICE",()->{Product p=(Product)spinner.getSelectedItem();String cn=customer.getText().toString().trim();double q=parse(quantity.getText().toString(),0);if(cn.isEmpty()){customer.setError("Enter customer name");return;}if(p==null||q<=0){toast("Enter a valid quantity");return;}if(q>p.stock){toast("Insufficient stock. Available: "+qty(p.stock));return;}double base=p.price*q,tax=base*p.gst/100.0,total=base+tax;String no="SKE-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date());long now=System.currentTimeMillis();long id=db.saveInvoice(no,cn,now,base,tax,total,p.id,p.name,q,p.price,p.gst);if(id>0){lastReceipt=receipt(no,cn,now,p.name,q,p.price,base,tax,total);toast("Invoice saved. Stock updated.");showInvoices();}else toast("Invoice could not be saved");});}

    private void showInvoices(){shell("Saved Invoices");Cursor c=db.invoices();if(c.getCount()==0)card("No invoices yet. Create your first bill.");while(c.moveToNext()){long id=c.getLong(0);String no=c.getString(1),customer=c.getString(2);long date=c.getLong(3);double subtotal=c.getDouble(4),gst=c.getDouble(5),total=c.getDouble(6);card(no+"\nCustomer: "+customer+"\n"+new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date(date))+"\nSubtotal ₹"+money(subtotal)+" | GST ₹"+money(gst)+"\nTOTAL ₹"+money(total));}c.close();button("OPEN PRINTER SETTINGS",()->showPrinter());}

    private void showPrinter(){shell("Bluetooth Thermal Printer");content.addView(text("Pair your printer first in Android Settings → Bluetooth.",15,false));RadioGroup group=new RadioGroup(this);RadioButton r58=new RadioButton(this);r58.setText("58mm paper");r58.setChecked(paperWidth==58);RadioButton r80=new RadioButton(this);r80.setText("80mm paper");r80.setChecked(paperWidth==80);group.addView(r58);group.addView(r80);group.setOnCheckedChangeListener((g,id)->paperWidth=id==r58.getId()?58:80);r58.setId(View.generateViewId());r80.setId(View.generateViewId());content.addView(group);
        button("FIND PAIRED PRINTERS",()->findPrinters());if(selectedPrinter!=null)card("Selected printer: "+safeName(selectedPrinter));button("PRINT LAST INVOICE",()->{if(lastReceipt.isEmpty()){toast("Create an invoice first in this session");return;}if(selectedPrinter==null){toast("Select a paired printer first");return;}printReceipt(lastReceipt);});card("Printer support uses Bluetooth Classic SPP / ESC-POS. Actual compatibility depends on the printer model and must be tested.");}
    private void findPrinters(){if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},BT_PERMISSION);return;}try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null){toast("This phone has no Bluetooth adapter");return;}Set<BluetoothDevice> devices=a.getBondedDevices();if(devices.isEmpty()){toast("No paired devices. Pair the printer in Android Settings first.");return;}String[] names=new String[devices.size()];ArrayList<BluetoothDevice> list=new ArrayList<>(devices);for(int i=0;i<list.size();i++)names[i]=safeName(list.get(i))+" — "+list.get(i).getAddress();new android.app.AlertDialog.Builder(this).setTitle("Choose printer").setItems(names,(d,which)->{selectedPrinter=list.get(which);toast("Selected: "+safeName(selectedPrinter));showPrinter();}).show();}catch(Exception e){toast("Bluetooth error: "+e.getMessage());}}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==BT_PERMISSION&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)findPrinters();else if(requestCode==BT_PERMISSION)toast("Bluetooth permission denied");}
    private String safeName(BluetoothDevice d){try{return d.getName()==null?"Bluetooth printer":d.getName();}catch(Exception e){return "Bluetooth printer";}}
    private void printReceipt(String receipt){new Thread(()->{try{UUID uuid=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");BluetoothSocket socket=selectedPrinter.createRfcommSocketToServiceRecord(uuid);socket.connect();OutputStream out=socket.getOutputStream();out.write(new byte[]{0x1B,0x40});out.write(receipt.getBytes("UTF-8"));out.write(new byte[]{10,10,10});out.flush();socket.close();runOnUiThread(()->toast("Print data sent"));}catch(Exception e){runOnUiThread(()->toast("Print failed: "+e.getMessage()));}}).start();}
    private String receipt(String no,String customer,long date,String product,double q,double price,double subtotal,double gst,double total){int width=paperWidth==58?32:48;String line="--------------------------------\n";return "SHRI KRISHNA ENTERPRISE\nHatiara 30C Busstand, Ghosh para\nKolkata - 700157\nPhone: 8910491316\n"+line+"Invoice: "+no+"\nDate: "+new Date(date)+"\nCustomer: "+customer+"\n"+line+product+"\nQty: "+qty(q)+" x ₹"+money(price)+"\nTaxable: ₹"+money(subtotal)+"\nGST: ₹"+money(gst)+"\nTOTAL: ₹"+money(total)+"\n"+line+"Thank you! Visit again.\n";}
    private static String money(double x){return String.format(Locale.US,"%.2f",x);}private static String qty(double x){return String.format(Locale.US,"%.2f",x);}private static double parse(String s,double fallback){try{return Double.parseDouble(s);}catch(Exception e){return fallback;}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
