package in.shrikrishnaenterprise.billing;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context context) { super(context, "shri_krishna_enterprise.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT)");
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,price REAL NOT NULL,gst REAL NOT NULL,stock REAL NOT NULL)");
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_no TEXT UNIQUE,customer TEXT,date_ms INTEGER,subtotal REAL,gst REAL,total REAL)");
        db.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,product_id INTEGER,product_name TEXT,qty REAL,price REAL,gst REAL,line_total REAL)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) { }

    public long addCustomer(String name,String phone,String address) {
        ContentValues v=new ContentValues(); v.put("name",name);v.put("phone",phone);v.put("address",address);
        return getWritableDatabase().insert("customers",null,v);
    }
    public long addProduct(String name,String code,double price,double gst,double stock) {
        ContentValues v=new ContentValues();v.put("name",name);v.put("code",code);v.put("price",price);v.put("gst",gst);v.put("stock",stock);
        return getWritableDatabase().insert("products",null,v);
    }
    public Cursor customers(){return getReadableDatabase().rawQuery("SELECT id,name,phone,address FROM customers ORDER BY name",null);}
    public Cursor products(){return getReadableDatabase().rawQuery("SELECT id,name,code,price,gst,stock FROM products ORDER BY name",null);}
    public Cursor invoices(){return getReadableDatabase().rawQuery("SELECT id,invoice_no,customer,date_ms,subtotal,gst,total FROM invoices ORDER BY date_ms DESC",null);}
    public double sales(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM invoices",null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public int customerCount(){return count("customers");}
    public int productCount(){return count("products");}
    private int count(String table){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);int n=0;if(c.moveToFirst())n=c.getInt(0);c.close();return n;}

    public long saveInvoice(String invoiceNo,String customer,long date,double subtotal,double gst,double total,
                            long productId,String productName,double qty,double price,double rate) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try {
            ContentValues inv=new ContentValues();inv.put("invoice_no",invoiceNo);inv.put("customer",customer);inv.put("date_ms",date);inv.put("subtotal",subtotal);inv.put("gst",gst);inv.put("total",total);
            long id=db.insertOrThrow("invoices",null,inv);
            ContentValues line=new ContentValues();line.put("invoice_id",id);line.put("product_id",productId);line.put("product_name",productName);line.put("qty",qty);line.put("price",price);line.put("gst",rate);line.put("line_total",total);
            db.insertOrThrow("invoice_items",null,line);
            db.execSQL("UPDATE products SET stock=stock-? WHERE id=?",new Object[]{qty,productId});
            db.setTransactionSuccessful(); return id;
        } finally { db.endTransaction(); }
    }
    public Cursor invoiceLines(long invoiceId){return getReadableDatabase().rawQuery("SELECT product_name,qty,price,gst,line_total FROM invoice_items WHERE invoice_id=?",new String[]{String.valueOf(invoiceId)});}
}
