plugins { id("com.android.application") }

android {
    namespace = "in.shrikrishnaenterprise.billing"
    compileSdk = 35
    defaultConfig {
        applicationId = "in.shrikrishnaenterprise.billing"
        minSdk = 23
        targetSdk = 35
        versionCode = 7
        versionName = "1.6.0"
    }
}
