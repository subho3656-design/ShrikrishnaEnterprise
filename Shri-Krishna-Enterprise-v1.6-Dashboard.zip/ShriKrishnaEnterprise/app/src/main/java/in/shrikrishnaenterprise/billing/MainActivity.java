package in.shrikrishnaenterprise.billing;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private DatabaseHelper db;
    private LinearLayout root, content;
    private String lastReceipt="";
    private BluetoothDevice selectedPrinter;
    private int paperWidth=58;
    private final ArrayList<Product> productData=new ArrayList<>();
    private static final int BT_PERMISSION=701, BACKUP_CREATE=702, BACKUP_RESTORE=703;
    private final int purple=Color.rgb(82,62,190), ink=Color.rgb(48,48,75), muted=Color.rgb(125,126,145), pale=Color.rgb(246,247,252);

    static class Product {
        long id; String name,unit; double price,gst,stock,caseSize;
        Product(long i,String n,double p,double g,double s,String u,double cs){id=i;name=n;price=p;gst=g;stock=s;unit=u;caseSize=cs;}
        @Override public String toString(){return name+"  |  ₹"+money(price)+" / "+unit+"  |  Stock: "+qty(stock)+" "+unit;}
    }

    static class BillRow { Spinner product,unit; EditText quantity; LinearLayout box; }
    static class DueInvoice { long id; String label; double balance; DueInvoice(long i,String l,double b){id=i;label=l;balance=b;} public String toString(){return label+"  |  Due ₹"+money(balance);} }

    @Override public void onCreate(Bundle state){super.onCreate(state);db=new DatabaseHelper(this);showDashboard();}

    private void shell(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(247,248,252));
        // Android 15 edge-to-edge safe area: keep app content between status and navigation bars.
        root.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(0,insets.getSystemWindowInsetTop(),0,insets.getSystemWindowInsetBottom());
            return insets;
        });
        root.setFitsSystemWindows(true);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(18,10,18,10);header.setBackgroundColor(Color.WHITE);
        TextView brand=new TextView(this);brand.setText("SHRI KRISHNA ENTERPRISE  ▾");brand.setTextColor(ink);brand.setTextSize(16);brand.setMaxLines(1);brand.setEllipsize(android.text.TextUtils.TruncateAt.END);brand.setTypeface(null,Typeface.BOLD);header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView quick=new TextView(this);quick.setText("▦   ♧   ▣");quick.setTextColor(purple);quick.setTextSize(21);header.addView(quick);root.addView(header);
        if(!"Dashboard".equals(title)){TextView sub=text(title,19,true);sub.setPadding(20,14,16,8);sub.setBackgroundColor(Color.WHITE);root.addView(sub);}
        ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(14,12,14,18);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setBackgroundColor(Color.WHITE);nav.setElevation(8);
        String[] tabs={"Dashboard","Parties","Items","Reports","More"};String[] icons={"⌂","♙","▣","▤","•••"};String active=title.equals("Customer Management")?"Parties":title.equals("Product and Stock Management")?"Items":title.equals("Reports")?"Reports":title.equals("Settings")||title.equals("Bluetooth Thermal Printer")?"More":title.equals("Saved Invoices")?"Dashboard":title;
        for(int i=0;i<tabs.length;i++){final String t=tabs[i];boolean selected=t.equals(active);LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);TextView iv=new TextView(this);iv.setText(icons[i]);iv.setTextSize(21);iv.setGravity(Gravity.CENTER);iv.setTextColor(selected?purple:muted);TextView tv=new TextView(this);tv.setText(t);tv.setTextSize(11);tv.setGravity(Gravity.CENTER);tv.setTextColor(selected?purple:muted);if(selected)tv.setTypeface(null,Typeface.BOLD);item.addView(iv);item.addView(tv);item.setPadding(2,5,2,5);nav.addView(item,new LinearLayout.LayoutParams(0,64,1));item.setOnClickListener(v->navigate(t));}
        root.addView(nav);setContentView(root);root.requestApplyInsets();
    }
    private void navigate(String t){switch(t){case "Dashboard":showDashboard();break;case "Parties":showCustomers();break;case "Items":showProducts();break;case "Reports":showReports();break;case "More":showMore();break;}}
    private TextView text(String s,int size,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(ink);if(bold)v.setTypeface(null,Typeface.BOLD);v.setPadding(4,7,4,7);return v;}
    private EditText field(String hint,int inputType){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setInputType(inputType);e.setTextSize(16);content.addView(e);return e;}
    private Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setOnClickListener(v->action.run());content.addView(b);return b;}
    private void section(String title){TextView h=text(title,17,true);h.setPadding(4,17,4,8);content.addView(h);}
    private GradientDrawable bg(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);d.setStroke(1,stroke);return d;}
    private void metric(LinearLayout row,String amount,String label,int fill,int stroke){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(13,10,10,9);box.setBackground(bg(fill,stroke,20));TextView a=text(amount,18,true);TextView l=text(label,13,true);l.setTextColor(label.contains("Collect")?Color.rgb(55,160,98):label.contains("Pay")?Color.rgb(205,91,91):muted);box.addView(a);box.addView(l);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,82,1);p.setMargins(5,5,5,5);row.addView(box,p);}
    private void dashboardTile(LinearLayout row,String amount,String label,int fill,int stroke){metric(row,amount,label,fill,stroke);}

    private void showDashboard(){
        shell("Dashboard");
        // Reference-style dashboard: six compact tiles in a two-column grid.
        LinearLayout r1=new LinearLayout(this);
        dashboardTile(r1,"₹ "+money(db.outstanding()),"To Collect  ↓",Color.rgb(235,247,239),Color.rgb(174,210,185));
        dashboardTile(r1,"₹ 0","To Pay  ↑",Color.rgb(251,239,239),Color.rgb(224,190,190));content.addView(r1);
        LinearLayout r2=new LinearLayout(this);
        dashboardTile(r2,"₹ "+money(db.stockValue()),"Stock Value · Value of Items",Color.rgb(244,248,252),Color.rgb(177,207,222));
        dashboardTile(r2,"₹ "+money(db.weeklySales()),"This week's sale",Color.rgb(244,248,252),Color.rgb(177,207,222));content.addView(r2);
        LinearLayout r3=new LinearLayout(this);
        dashboardTile(r3,"₹ 0","Total Balance · Cash + Bank Balance",Color.rgb(244,248,252),Color.rgb(177,207,222));
        dashboardTile(r3,"Reports","Sales, Party, GST...",Color.rgb(244,248,252),Color.rgb(177,207,222));content.addView(r3);
        TextView reports=text("👑   View unlimited reports                                      ›",15,true);
        reports.setTextColor(ink);reports.setPadding(12,18,8,18);reports.setBackground(bg(Color.WHITE,Color.rgb(232,232,238),12));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(-14,12,-14,12);content.addView(reports,rp);reports.setOnClickListener(v->showReports());
        LinearLayout txHead=new LinearLayout(this);txHead.setGravity(Gravity.CENTER_VERTICAL);
        txHead.addView(text("Transactions",17,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView period=text("▦  LAST 365 DAYS",13,true);period.setTextColor(purple);txHead.addView(period);content.addView(txHead);
        Cursor c=db.invoices();int shown=0;
        while(c.moveToNext()&&shown<8){
            String no=c.getString(1),customer=c.getString(2);long date=c.getLong(3);double total=c.getDouble(6);
            LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setPadding(15,12,15,12);item.setBackground(bg(Color.WHITE,Color.rgb(231,231,236),14));
            item.addView(text(customer,16,true));
            TextView detail=text("Invoice  "+no,13,true);detail.setTextColor(muted);item.addView(detail);
            LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);
            TextView dateView=text(new SimpleDateFormat("dd MMM",Locale.getDefault()).format(new Date(date)),13,false);dateView.setTextColor(muted);line.addView(dateView,new LinearLayout.LayoutParams(0,-2,1));
            line.addView(text("₹ "+money(total),16,true));item.addView(line);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,7,0,7);content.addView(item,lp);shown++;
        }
        c.close();if(shown==0)card("No transactions yet. Create your first bill.");
        // Fixed action dock, like the supplied reference, stays above bottom navigation.
        LinearLayout dock=new LinearLayout(this);dock.setGravity(Gravity.CENTER_VERTICAL);dock.setPadding(10,5,10,7);dock.setBackgroundColor(Color.WHITE);
        Button collect=buttonInline("Received Payment",()->showCollectPayment());collect.setAllCaps(false);collect.setTextColor(Color.WHITE);collect.setTextSize(14);collect.setBackground(bg(ink,ink,40));
        Button plus=buttonInline("+",()->showProducts());plus.setTextColor(Color.WHITE);plus.setTextSize(23);plus.setBackground(bg(Color.rgb(111,190,139),Color.rgb(111,190,139),50));
        Button bill=buttonInline("+ Bill / Invoice",()->showNewBill());bill.setAllCaps(false);bill.setTextColor(Color.WHITE);bill.setTextSize(15);bill.setBackground(bg(purple,purple,40));
        LinearLayout.LayoutParams d1=new LinearLayout.LayoutParams(0,54,1.05f);d1.setMargins(3,0,6,0);dock.addView(collect,d1);
        LinearLayout.LayoutParams d2=new LinearLayout.LayoutParams(52,52);d2.setMargins(2,0,6,0);dock.addView(plus,d2);
        LinearLayout.LayoutParams d3=new LinearLayout.LayoutParams(0,54,1.1f);d3.setMargins(2,0,3,0);dock.addView(bill,d3);
        root.addView(dock,Math.max(0,root.getChildCount()-1));
    }
    private Button buttonInline(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setOnClickListener(v->action.run());return b;}
    private void card(String s){TextView v=text(s,15,false);v.setBackground(bg(Color.WHITE,Color.rgb(230,230,236),14));v.setPadding(15,14,15,14);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,5);content.addView(v,p);}

    private void showCustomers(){shell("Parties");LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.addView(text("Customer list",17,true),new LinearLayout.LayoutParams(0,-2,1));Button add=buttonInline("+ Create Party",()->addCustomerForm());add.setTextColor(Color.WHITE);add.setBackgroundTintList(ColorStateList.valueOf(purple));top.addView(add);content.addView(top);EditText search=new EditText(this);search.setSingleLine(true);search.setHint("Search parties");content.addView(search);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);Runnable load=()->{list.removeAllViews();Cursor c=db.customers();String q=search.getText().toString().toLowerCase(Locale.ROOT);while(c.moveToNext()){String name=c.getString(1),phone=c.getString(2),address=c.getString(3);if(name.toLowerCase(Locale.ROOT).contains(q)||phone.toLowerCase(Locale.ROOT).contains(q)){TextView row=text(name+"\nCustomer"+(phone.isEmpty()?"":"  •  "+phone)+"\n"+(address==null?"":address),16,true);row.setBackground(bg(Color.WHITE,Color.rgb(229,229,236),14));row.setPadding(16,14,16,14);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,5);list.addView(row,lp);row.setOnClickListener(v->showCustomerLedger(name));}}c.close();if(list.getChildCount()==0){TextView empty=text("No matching parties",14,false);list.addView(empty);}};search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){load.run();}public void afterTextChanged(android.text.Editable e){}});load.run();}
    private void showCustomerLedger(String customerName){
        shell("Customer Ledger");
        double opening=0;
        Cursor customers=db.customers();
        while(customers.moveToNext()){
            if(customerName.equals(customers.getString(1))){opening=customers.getDouble(4);break;}
        }
        customers.close();
        section(customerName);
        card("Opening balance / previous due: ₹"+money(opening));
        Cursor c=db.customerLedgerByName(customerName);
        double running=opening;
        if(c.getCount()==0) card("No invoices recorded for this customer.");
        while(c.moveToNext()){
            String no=c.getString(0);long date=c.getLong(1);
            double total=c.getDouble(2),paid=c.getDouble(3),balance=c.getDouble(4);
            running+=total-paid;
            card(no+"\n"+new SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(new Date(date))+
                 "\nInvoice: ₹"+money(total)+" | Paid: ₹"+money(paid)+
                 "\nDue: ₹"+money(balance)+"\nRunning balance: ₹"+money(running));
        }
        c.close();
        card("Previous balance still due: Rs."+money(db.customerOpeningDue(customerName))+
             "\nTotal amount to collect: Rs."+money(db.customerInvoiceOutstanding(customerName)));
        button("COLLECT PAYMENT",()->showCollectPayment());
    }

    private void addCustomerForm(){shell("Create Party");EditText n=field("Customer name",1),p=field("Mobile number",3),a=field("Address",1),opening=field("Previous balance / opening due (Rs.)",8194);opening.setText("0");card("Previous balance is added to this customer's amount to collect. Enter 0 for a new customer.");button("SAVE PARTY",()->{String name=n.getText().toString().trim();double due=parse(opening.getText().toString(),-1);if(name.isEmpty()){n.setError("Enter customer name");return;}if(due<0){opening.setError("Enter a valid amount");return;}long id=db.addCustomer(name,p.getText().toString().trim(),a.getText().toString().trim(),due);if(id>0){toast("Party saved with opening balance");showCustomers();}else toast("Could not save party");});}

    private void showProducts(){shell("Items");LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.addView(text("Product catalogue",17,true),new LinearLayout.LayoutParams(0,-2,1));Button add=buttonInline("+ Create New Item",()->addProductForm());add.setTextColor(Color.WHITE);add.setBackgroundTintList(ColorStateList.valueOf(purple));top.addView(add);content.addView(top);EditText search=new EditText(this);search.setSingleLine(true);search.setHint("Search items");content.addView(search);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);Runnable load=()->{list.removeAllViews();Cursor c=db.products();String q=search.getText().toString().toLowerCase(Locale.ROOT);while(c.moveToNext()){String name=c.getString(1),code=c.getString(2);if(name.toLowerCase(Locale.ROOT).contains(q)||(code!=null&&code.toLowerCase(Locale.ROOT).contains(q))){TextView row=text(name+"                                      "+qty(c.getDouble(5))+" "+c.getString(7)+"\nSales Price   ₹"+money(c.getDouble(3))+"\nPurchase Price ₹"+money(c.getDouble(6))+"\nGST "+money(c.getDouble(4))+"%",15,true);row.setBackground(bg(Color.WHITE,Color.rgb(229,229,236),14));row.setPadding(16,13,16,13);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);list.addView(row,lp);}}c.close();if(list.getChildCount()==0)list.addView(text("No matching items",14,false));};search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){load.run();}public void afterTextChanged(android.text.Editable e){}});load.run();}
    private void addProductForm(){shell("Create New Item");EditText n=field("Item name",1),code=field("Product code / SKU",1),price=field("Sales price (₹ per unit)",8194),purchase=field("Purchase price (₹ per unit)",8194),gst=field("GST percentage (0 for non-taxable)",8194),stock=field("Opening stock quantity",8194),caseSize=field("Units per case / box (default 1)",8194);Spinner unit=new Spinner(this);String[] units={"PCS","CASE"};unit.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,units));content.addView(text("Stock unit",15,true));content.addView(unit);button("SAVE ITEM",()->{try{String name=n.getText().toString().trim();if(name.isEmpty()){n.setError("Enter item name");return;}double pr=Double.parseDouble(price.getText().toString()),pp=parse(purchase.getText().toString(),0),g=Double.parseDouble(gst.getText().toString()),q=Double.parseDouble(stock.getText().toString()),cs=parse(caseSize.getText().toString(),1);if(pr<0||pp<0||g<0||g>100||q<0||cs<=0)throw new NumberFormatException();long id=db.addProduct(name,code.getText().toString().trim(),pr,pp,g,q,(String)unit.getSelectedItem(),cs,null);if(id>0){toast("Item saved offline");showProducts();}else toast("Could not save item");}catch(Exception ex){toast("Enter valid prices, GST, stock and case size");}});}

    private void showReports(){shell("Reports");section("Popular");reportRow("Sales Summary","Total sales and invoice history",()->showInvoices());reportRow("Daybook","Daily invoice activity",()->showInvoices());reportRow("Stock Summary","Current quantity and stock value",()->showProducts());reportRow("Party Statement (Ledger)","Not available yet — party balances are not tracked",()->toast("Party ledger is planned for a future update"));reportRow("Profit and Loss","Not available yet — purchase costs and expenses are not tracked",()->toast("Profit and Loss is planned for a future update"));reportRow("GST Reports","Invoice-wise GST totals",()->showInvoices());reportRow("Cash and Bank","Not available yet — payment modes are not tracked",()->toast("Cash and Bank report is planned for a future update"));}
    private void reportRow(String title,String desc,Runnable click){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(13,9,13,9);box.setBackground(bg(Color.WHITE,Color.rgb(231,231,238),12));TextView t=text("▤   "+title+"     ›",16,true);TextView d=text(desc,12,false);d.setTextColor(muted);box.addView(t);box.addView(d);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,4,0,5);content.addView(box,lp);box.setOnClickListener(v->click.run());}
    private void showMore(){shell("More");section("Settings");reportRow("Invoice Settings","Business name and invoice preferences",()->showInvoiceSettings());reportRow("Account Settings","Local app information",()->showSettingsInfo());reportRow("Printer Settings","Bluetooth 58mm / 80mm printer",()->showPrinter());reportRow("Sales Returns","Record damaged, expired or unsold goods",()->showReturnsInfo());reportRow("Backup & Restore","Export a local database backup or save it to Google Drive",()->showBackupInfo());reportRow("GST Rate Finder","GST rate entered per item",()->toast("Set GST rate when creating an item"));reportRow("About","Offline billing app for Shri Krishna Enterprise",()->showSettingsInfo());}
    private void showInvoiceSettings(){shell("Invoice Settings");card("Business: Shri Krishna Enterprise\nAddress: Hatiara 30C Busstand, Ghosh para, Kolkata - 700157\nInvoice format: SKE-YYYYMMDD-HHMMSS\nGST is calculated using the rate saved on each item.");card("Invoice settings are currently read-only in this starter version.");}
    private void showReturnsInfo(){shell("Sales Returns");loadProductData();if(productData.isEmpty()){card("Add products before recording a return.");return;}EditText customer=field("Customer / shop name",1);Spinner product=new Spinner(this);product.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,productData));content.addView(text("Returned product",15,true));content.addView(product);EditText quantity=field("Returned quantity",8194);quantity.setText("1");Spinner reason=new Spinner(this);reason.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"UNSOLD","DAMAGED","EXPIRY"}));content.addView(text("Return reason",15,true));content.addView(reason);Spinner disposition=new Spinner(this);disposition.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Return to saleable stock","Do not add back to stock"}));content.addView(text("Stock treatment",15,true));content.addView(disposition);card("Unsold goods may be returned to stock after checking. Damaged and expired goods should normally be kept out of saleable stock. Verify the physical goods before saving.");button("SAVE RETURN",()->{Product p=(Product)product.getSelectedItem();String cn=customer.getText().toString().trim();double q=parse(quantity.getText().toString(),0);if(cn.isEmpty()){customer.setError("Enter customer name");return;}if(p==null||q<=0){quantity.setError("Enter a valid quantity");return;}boolean restock=disposition.getSelectedItemPosition()==0;if(("DAMAGED".equals(reason.getSelectedItem())||"EXPIRY".equals(reason.getSelectedItem()))&&restock){toast("Damaged or expired goods should not be added to saleable stock");return;}double amount=q*p.price;ArrayList<DatabaseHelper.InvoiceLine> lines=new ArrayList<>();lines.add(new DatabaseHelper.InvoiceLine(p.id,p.name,q,p.price,p.gst,amount,p.unit,q));String no="RET-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date());long id=db.saveReturn(no,-1,cn,System.currentTimeMillis(),(String)reason.getSelectedItem(),"CREDIT","Return recorded",lines,restock);if(id>0){toast("Return recorded");showProducts();}else toast("Could not save return");});}
    private void showBackupInfo(){shell("Backup & Restore");card("Create a database backup and save it on this phone or choose Google Drive in the Android file picker. Restore replaces the current local database, so export a backup first.");button("BACK UP DATABASE",()->startBackup());button("RESTORE DATABASE",()->new android.app.AlertDialog.Builder(this).setTitle("Replace current data?").setMessage("Restoring replaces the database currently on this phone. Make a backup first. Continue?").setNegativeButton("CANCEL",null).setPositiveButton("CONTINUE",(d,w)->startRestore()).show());}
    private void startBackup(){android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT);i.addCategory(android.content.Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(android.content.Intent.EXTRA_TITLE,"ShriKrishnaEnterprise-backup.db");startActivityForResult(i,BACKUP_CREATE);}
    private void startRestore(){android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);i.addCategory(android.content.Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,BACKUP_RESTORE);}
    @Override protected void onActivityResult(int requestCode,int resultCode,android.content.Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;try{java.io.File target=getDatabasePath("shri_krishna_enterprise.db");db.close();if(requestCode==BACKUP_CREATE){try(java.io.InputStream in=new java.io.FileInputStream(target);java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)throw new java.io.IOException("Cannot open destination");byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}db=new DatabaseHelper(this);toast("Backup saved. You can choose phone storage or Google Drive.");showBackupInfo();}else if(requestCode==BACKUP_RESTORE){new java.io.File(target.getPath()+"-wal").delete();new java.io.File(target.getPath()+"-shm").delete();java.io.File temp=new java.io.File(getCacheDir(),"restore.db");try(java.io.InputStream in=getContentResolver().openInputStream(data.getData());java.io.OutputStream out=new java.io.FileOutputStream(temp)){if(in==null)throw new java.io.IOException("Cannot open backup");byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}if(temp.length()<1024)throw new java.io.IOException("Backup file is too small");try(java.io.InputStream in=new java.io.FileInputStream(temp);java.io.OutputStream out=new java.io.FileOutputStream(target)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}temp.delete();db=new DatabaseHelper(this);db.getReadableDatabase();toast("Backup restored successfully");showDashboard();}}catch(Exception e){db=new DatabaseHelper(this);toast("Backup operation failed: "+e.getMessage());}}
    private void showSettingsInfo(){shell("Settings");card("Shri Krishna Enterprise\nOffline SQLite storage\nNo cloud account or subscription required.");card("Important: uninstalling the app or clearing its storage can erase saved customers, items and invoices. Backup and restore are not yet included.");}

    private void loadProductData(){productData.clear();Cursor c=db.products();while(c.moveToNext())productData.add(new Product(c.getLong(0),c.getString(1),c.getDouble(3),c.getDouble(4),c.getDouble(5),c.getString(7),c.getDouble(8)));c.close();}
    private void showNewBill(){
        shell("Create New Bill");loadProductData();
        if(productData.isEmpty()){card("Add products first in Items before creating a bill.");button("GO TO ITEMS",()->showProducts());return;}
        EditText customer=field("Customer name",1);
        Spinner billType=new Spinner(this);billType.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"GST Invoice","Non-GST Bill"}));content.addView(text("Bill type",15,true));content.addView(billType);
        Spinner paymentMode=new Spinner(this);paymentMode.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"CREDIT","CASH","UPI","BANK"}));content.addView(text("Payment mode",15,true));content.addView(paymentMode);
        EditText paidField=field("Amount received now (₹). For credit enter 0",8194);paidField.setText("0");
        section("Invoice items");LinearLayout rowsBox=new LinearLayout(this);rowsBox.setOrientation(LinearLayout.VERTICAL);content.addView(rowsBox);
        ArrayList<BillRow> rows=new ArrayList<>();TextView summary=text("Add products below",16,true);content.addView(summary);
        Runnable refresh=()->{double taxable=0,tax=0;HashMap<Long,Double> used=new HashMap<>();StringBuilder lines=new StringBuilder();for(BillRow r:rows){Product p=(Product)r.product.getSelectedItem();double q=parse(r.quantity.getText().toString(),0);if(p!=null&&q>0){boolean asCase=r.unit.getSelectedItemPosition()==1;double stockQty=stockQuantity(p,q,asCase);double unitPrice=saleUnitPrice(p,asCase);double base=unitPrice*q,t=billType.getSelectedItemPosition()==0?base*p.gst/100.0:0;taxable+=base;tax+=t;used.put(p.id,used.containsKey(p.id)?used.get(p.id)+stockQty:stockQty);lines.append(p.name).append("  ").append(qty(q)).append(asCase?" CASE":" PCS").append(" x ₹").append(money(unitPrice)).append(" = ₹").append(money(base+t)).append("\n");}}StringBuilder warnings=new StringBuilder();for(Product p:productData){Double q=used.get(p.id);if(q!=null&&q>p.stock)warnings.append("\nLOW STOCK: ").append(p.name).append(" available ").append(qty(p.stock));}summary.setText(lines+"\nTaxable: ₹"+money(taxable)+"\nGST: ₹"+money(tax)+"\nTOTAL: ₹"+money(taxable+tax)+warnings);};
        Runnable addRow=()->{BillRow r=new BillRow();r.box=new LinearLayout(this);r.box.setOrientation(LinearLayout.VERTICAL);r.box.setPadding(10,8,10,8);r.box.setBackground(bg(Color.WHITE,Color.rgb(225,225,235),12));LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.addView(text("Item "+(rows.size()+1),14,true),new LinearLayout.LayoutParams(0,-2,1));Button remove=buttonInline("REMOVE",()->{if(rows.size()==1){toast("At least one item is required");return;}rowsBox.removeView(r.box);rows.remove(r);refresh.run();});top.addView(remove);r.box.addView(top);r.product=new Spinner(this);r.product.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,productData));r.box.addView(r.product);r.unit=new Spinner(this);r.unit.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"PCS","CASE"}));r.box.addView(text("Sale unit",13,false));r.box.addView(r.unit);r.quantity=new EditText(this);r.quantity.setSingleLine(true);r.quantity.setInputType(8194);r.quantity.setHint("Quantity");r.quantity.setText("1");r.box.addView(r.quantity);r.product.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){refresh.run();}public void onNothingSelected(android.widget.AdapterView<?> a){}});r.unit.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){refresh.run();}public void onNothingSelected(android.widget.AdapterView<?> a){}});r.quantity.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(android.text.Editable e){}});rows.add(r);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,5);rowsBox.addView(r.box,lp);refresh.run();};
        addRow.run();button("+ ADD ANOTHER ITEM",()->addRow.run());
        button("SAVE INVOICE",()->{String cn=customer.getText().toString().trim();if(cn.isEmpty()){customer.setError("Enter customer name");return;}ArrayList<DatabaseHelper.InvoiceLine> lines=new ArrayList<>();HashMap<Long,Double> used=new HashMap<>();double taxable=0,tax=0;for(BillRow r:rows){Product p=(Product)r.product.getSelectedItem();double q=parse(r.quantity.getText().toString(),0);if(p==null||q<=0){r.quantity.setError("Enter valid quantity");return;}boolean asCase=r.unit.getSelectedItemPosition()==1;double stockQty=stockQuantity(p,q,asCase),unitPrice=saleUnitPrice(p,asCase);used.put(p.id,used.containsKey(p.id)?used.get(p.id)+stockQty:stockQty);double base=unitPrice*q,t=billType.getSelectedItemPosition()==0?base*p.gst/100.0:0;taxable+=base;tax+=t;lines.add(new DatabaseHelper.InvoiceLine(p.id,p.name,q,unitPrice,billType.getSelectedItemPosition()==0?p.gst:0,base+t,asCase?"CASE":"PCS",stockQty));}for(Product p:productData){Double q=used.get(p.id);if(q!=null&&q>p.stock){toast("Insufficient stock for "+p.name+". Available: "+qty(p.stock));return;}}double total=taxable+tax,paid=parse(paidField.getText().toString(),-1);if(paid<0||paid>total){paidField.setError("Enter amount between 0 and invoice total");return;}String mode=(String)paymentMode.getSelectedItem();if("CREDIT".equals(mode)&&paid>0)mode="MIXED";String no="SKE-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date());long now=System.currentTimeMillis();long id=db.saveInvoiceMulti(no,cn,-1,now,taxable,tax,total,billType.getSelectedItemPosition()==0?"GST":"NON_GST",mode,paid,lines);if(id>0){lastReceipt=receiptMulti(no,cn,now,lines,taxable,tax,total,paid);toast("Invoice saved. Stock updated.");showInvoices();}else toast("Invoice not saved. Check stock and try again.");});refresh.run();
    }
    private double stockQuantity(Product p,double saleQty,boolean asCase){if("PCS".equalsIgnoreCase(p.unit))return asCase?saleQty*p.caseSize:saleQty;return asCase?saleQty:saleQty/Math.max(1,p.caseSize);}
    private double saleUnitPrice(Product p,boolean asCase){if("PCS".equalsIgnoreCase(p.unit))return asCase?p.price*p.caseSize:p.price;return asCase?p.price:p.price/Math.max(1,p.caseSize);}
    private String receiptMulti(String no,String customer,long date,ArrayList<DatabaseHelper.InvoiceLine> lines,double taxable,double gst,double total,double paid){
        StringBuilder b=new StringBuilder();
        b.append("[BOLD]").append("SHRI KRISHNA ENTERPRISE").append("[NORMAL]").append("\n")
         .append("Hatiara 30C Busstand, Ghosh para\nKolkata - 700157\n")
         .append("--------------------------------\nInvoice: ").append(no)
         .append("\nDate: ").append(new Date(date)).append("\nCustomer: ")
         .append("[BOLD]").append(customer).append("[NORMAL]").append("\n")
         .append("--------------------------------\n");
        for(DatabaseHelper.InvoiceLine l:lines){
            b.append(l.productName).append("\n")
             .append(qty(l.quantity)).append(" ").append(l.unit)
             .append(" x Rs.").append(money(l.price))
             .append(" = Rs.").append(money(l.lineTotal)).append("\n");
        }
        return b.append("--------------------------------\n")
            .append("Taxable: Rs.").append(money(taxable)).append("\n")
            .append("GST: Rs.").append(money(gst)).append("\n")
            .append("[BOLD]").append("TOTAL: Rs.").append(money(total)).append("[NORMAL]").append("\n")
            .append("Received: Rs.").append(money(paid)).append("\n")
            .append("Balance: Rs.").append(money(total-paid)).append("\n")
            .append("Thank you! Visit again.\n").toString();
    }
    private void showCollectPayment(){
        shell("Collect Payment");
        Cursor c=db.invoices();
        LinkedHashSet<String> customerNames=new LinkedHashSet<>();
        while(c.moveToNext()){
            double due=c.getDouble(6)-c.getDouble(9);
            if(due>0.000001) customerNames.add(c.getString(2));
        }
        c.close();
        Cursor parties=db.customers();
        while(parties.moveToNext()){
            if(parties.getDouble(4)>0.000001 || db.customerInvoiceOutstanding(parties.getString(1))>0.000001)
                customerNames.add(parties.getString(1));
        }
        parties.close();
        if(customerNames.isEmpty()){card("No outstanding invoices. All recorded invoices are paid.");return;}
        ArrayList<String> names=new ArrayList<>(customerNames);
        Spinner customer=new Spinner(this);
        customer.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
        content.addView(text("Customer / shop",15,true));content.addView(customer);
        TextView dueLabel=text("",16,true);content.addView(dueLabel);
        Runnable showDue=()->{
            String name=(String)customer.getSelectedItem();
            dueLabel.setText("Previous balance: Rs."+money(db.customerOpeningDue(name))+
                    "\nTotal amount to collect: Rs."+money(db.customerInvoiceOutstanding(name))+
                    "\nPayment settles previous balance first, then oldest unpaid invoices.");
        };
        customer.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){showDue.run();}
            public void onNothingSelected(android.widget.AdapterView<?> a){}
        });
        EditText amount=field("Amount collected (₹)",8194);
        Spinner mode=new Spinner(this);
        mode.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"CASH","UPI","BANK"}));
        content.addView(text("Payment method",15,true));content.addView(mode);
        showDue.run();
        button("SAVE PAYMENT",()->{
            String name=(String)customer.getSelectedItem();
            double a=parse(amount.getText().toString(),0);
            double due=db.customerInvoiceOutstanding(name);
            if(a<=0||a>due+0.000001){amount.setError("Enter an amount up to ₹"+money(due));return;}
            boolean ok=db.recordCustomerPaymentFIFO(name,a,(String)mode.getSelectedItem(),
                    System.currentTimeMillis(),"Customer receipt — FIFO allocation");
            if(ok){toast("Payment saved and allocated oldest-first");showDashboard();}
            else toast("Payment could not be saved. Check outstanding balance.");
        });
    }

    private void showInvoices(){
        shell("Saved Invoices");
        Cursor c=db.invoices();
        if(c.getCount()==0)card("No invoices yet. Create your first bill.");
        while(c.moveToNext()){
            long id=c.getLong(0);
            String no=c.getString(1),customer=c.getString(2);
            long date=c.getLong(3);
            double subtotal=c.getDouble(4),gst=c.getDouble(5),total=c.getDouble(6),paid=c.getDouble(9);
            String status=c.getString(10);
            LinearLayout item=new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(14,10,14,10);
            item.setBackground(bg(Color.WHITE,Color.rgb(230,230,236),16));
            item.addView(text(customer,17,true));
            item.addView(text(no+"  •  "+new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date(date)),13,false));
            item.addView(text("Subtotal Rs."+money(subtotal)+" | GST Rs."+money(gst)+
                    "\\nTOTAL Rs."+money(total)+"\\nReceived Rs."+money(paid)+
                    " | Balance Rs."+money(total-paid)+" | "+status,14,true));
            Button reprint=buttonInline("REPRINT BILL",()->reprintInvoice(id));
            reprint.setAllCaps(false);
            reprint.setTextSize(14);
            reprint.setTextColor(Color.WHITE);
            reprint.setBackgroundTintList(ColorStateList.valueOf(purple));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,48);
            rp.setMargins(0,8,0,0);
            item.addView(reprint,rp);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
            lp.setMargins(0,5,0,5);
            content.addView(item,lp);
        }
        c.close();
        button("COLLECT PAYMENT",()->showCollectPayment());
        button("OPEN PRINTER SETTINGS",()->showPrinter());
        button("CREATE NEW BILL",()->showNewBill());
    }

    private void reprintInvoice(long invoiceId){
        if(selectedPrinter==null){
            new android.app.AlertDialog.Builder(this)
                .setTitle("Printer not selected")
                .setMessage("Choose your paired Bluetooth printer first.")
                .setPositiveButton("OPEN PRINTER SETTINGS",(dialog,which)->showPrinter())
                .setNegativeButton("CANCEL",null).show();
            return;
        }
        Cursor h=db.invoiceForPrint(invoiceId);
        if(!h.moveToFirst()){h.close();toast("Invoice not found");return;}
        String no=h.getString(0),customer=h.getString(1);
        long date=h.getLong(2);
        double taxable=h.getDouble(3),gst=h.getDouble(4),total=h.getDouble(5),paid=h.getDouble(6);
        h.close();
        StringBuilder b=new StringBuilder();
        b.append("[BOLD]").append("SHRI KRISHNA ENTERPRISE").append("[NORMAL]").append("\n")
         .append("Hatiara 30C Busstand, Ghosh para\nKolkata - 700157\n")
         .append("--------------------------------\nInvoice: ").append(no)
         .append("\nDate: ").append(new Date(date)).append("\nCustomer: ")
         .append("[BOLD]").append(customer).append("[NORMAL]").append("\n")
         .append("--------------------------------\n");
        Cursor lines=db.invoiceLines(invoiceId);
        while(lines.moveToNext()){
            b.append(lines.getString(0)).append("\n")
             .append(qty(lines.getDouble(1))).append(" ").append(lines.getString(5))
             .append(" x Rs.").append(money(lines.getDouble(2)))
             .append(" = Rs.").append(money(lines.getDouble(4))).append("\n");
        }
        lines.close();
        String receipt=b.append("--------------------------------\n")
            .append("Taxable: Rs.").append(money(taxable)).append("\n")
            .append("GST: Rs.").append(money(gst)).append("\n")
            .append("[BOLD]").append("TOTAL: Rs.").append(money(total)).append("[NORMAL]").append("\n")
            .append("Received: Rs.").append(money(paid)).append("\n")
            .append("Balance: Rs.").append(money(total-paid)).append("\n")
            .append("Thank you! Visit again.\n").toString();
        lastReceipt=receipt;
        printReceipt(receipt);
    }

    private void showPrinter(){shell("Bluetooth Thermal Printer");content.addView(text("Pair your printer first in Android Settings → Bluetooth.",15,false));RadioGroup group=new RadioGroup(this);RadioButton r58=new RadioButton(this);r58.setText("58mm paper");r58.setChecked(paperWidth==58);RadioButton r80=new RadioButton(this);r80.setText("80mm paper");r80.setChecked(paperWidth==80);r58.setId(View.generateViewId());r80.setId(View.generateViewId());group.addView(r58);group.addView(r80);group.setOnCheckedChangeListener((g,id)->paperWidth=id==r58.getId()?58:80);content.addView(group);button("FIND PAIRED PRINTERS",()->findPrinters());if(selectedPrinter!=null)card("Selected printer: "+safeName(selectedPrinter));button("PRINT LAST INVOICE",()->{if(lastReceipt.isEmpty()){toast("No recent invoice in this session. Use Reprint from Saved Invoices.");return;}if(selectedPrinter==null){toast("Select a paired printer first");return;}printReceipt(lastReceipt);});button("REPRINT A SAVED BILL",()->showInvoices());card("Printer support uses Bluetooth Classic SPP / ESC-POS. Actual compatibility depends on the printer model and must be tested.");}
    private void findPrinters(){if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},BT_PERMISSION);return;}try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null){toast("This phone has no Bluetooth adapter");return;}Set<BluetoothDevice> devices=a.getBondedDevices();if(devices.isEmpty()){toast("No paired devices. Pair the printer in Android Settings first.");return;}String[] names=new String[devices.size()];ArrayList<BluetoothDevice> list=new ArrayList<>(devices);for(int i=0;i<list.size();i++)names[i]=safeName(list.get(i))+" — "+list.get(i).getAddress();new android.app.AlertDialog.Builder(this).setTitle("Choose printer").setItems(names,(d,which)->{selectedPrinter=list.get(which);toast("Selected: "+safeName(selectedPrinter));showPrinter();}).show();}catch(Exception e){toast("Bluetooth error: "+e.getMessage());}}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==BT_PERMISSION&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)findPrinters();else if(requestCode==BT_PERMISSION)toast("Bluetooth permission denied");}
    private String safeName(BluetoothDevice d){try{return d.getName()==null?"Bluetooth printer":d.getName();}catch(Exception e){return "Bluetooth printer";}}
    private void printReceipt(String receipt){new Thread(()->{try{UUID uuid=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");BluetoothSocket socket=selectedPrinter.createRfcommSocketToServiceRecord(uuid);socket.connect();OutputStream out=socket.getOutputStream();out.write(new byte[]{0x1B,0x40});String safe=receipt.replace("₹","Rs.").replace("—","-").replace("•","-");String[] parts=safe.split("\\[BOLD\\]|\\[NORMAL\\]",-1);int pos=0;java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("\\[BOLD\\]|\\[NORMAL\\]").matcher(safe);while(matcher.find()){if(matcher.start()>pos)out.write(safe.substring(pos,matcher.start()).getBytes(java.nio.charset.StandardCharsets.US_ASCII));out.write(new byte[]{0x1B,0x45,(byte)(matcher.group().equals("[BOLD]")?1:0)});pos=matcher.end();}if(pos<safe.length())out.write(safe.substring(pos).getBytes(java.nio.charset.StandardCharsets.US_ASCII));out.write(new byte[]{0x1B,0x45,0,10,10,10});out.flush();socket.close();runOnUiThread(()->toast("Print data sent"));}catch(Exception e){runOnUiThread(()->toast("Print failed: "+e.getMessage()));}}).start();}
    private static String money(double x){return String.format(Locale.US,"%.2f",x);}private static String qty(double x){return String.format(Locale.US,"%.2f",x);}private static double parse(String s,double fallback){try{return Double.parseDouble(s);}catch(Exception e){return fallback;}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
