plugins { id("com.android.application") }

android {
    namespace = "in.shrikrishnaenterprise.billing"
    compileSdk = 35
    defaultConfig {
        applicationId = "in.shrikrishnaenterprise.billing"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"
    }
}
