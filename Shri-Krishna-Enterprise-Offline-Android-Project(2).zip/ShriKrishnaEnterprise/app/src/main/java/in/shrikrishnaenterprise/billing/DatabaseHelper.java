package in.shrikrishnaenterprise.billing;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/** Local-first business database. Schema v2 preserves v1 records during upgrade. */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "shri_krishna_enterprise.db";
    private static final int DB_VERSION = 2;

    public static class InvoiceLine {
        public long productId;
        public String productName, unit;
        public double quantity, stockQuantity, price, gstRate, lineTotal;
        public InvoiceLine(long productId, String productName, double quantity,
                           double price, double gstRate, double lineTotal) {
            this(productId, productName, quantity, price, gstRate, lineTotal, "PCS", quantity);
        }
        public InvoiceLine(long productId, String productName, double quantity,
                           double price, double gstRate, double lineTotal, String unit) {
            this(productId, productName, quantity, price, gstRate, lineTotal, unit, quantity);
        }
        public InvoiceLine(long productId, String productName, double quantity,
                           double price, double gstRate, double lineTotal, String unit, double stockQuantity) {
            this.productId=productId; this.productName=productName; this.quantity=quantity;
            this.stockQuantity=stockQuantity; this.price=price; this.gstRate=gstRate; this.lineTotal=lineTotal;
            this.unit=unit==null?"PCS":unit;
        }
    }

    public DatabaseHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,opening_balance REAL NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,price REAL NOT NULL,gst REAL NOT NULL,stock REAL NOT NULL,purchase_price REAL NOT NULL DEFAULT 0,unit TEXT NOT NULL DEFAULT 'PCS',case_size REAL NOT NULL DEFAULT 1,hsn TEXT)");
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_no TEXT UNIQUE,customer TEXT,date_ms INTEGER,subtotal REAL,gst REAL,total REAL,invoice_type TEXT NOT NULL DEFAULT 'GST',payment_mode TEXT NOT NULL DEFAULT 'CREDIT',paid_amount REAL NOT NULL DEFAULT 0,payment_status TEXT NOT NULL DEFAULT 'UNPAID',customer_id INTEGER)");
        db.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,product_id INTEGER,product_name TEXT,qty REAL,price REAL,gst REAL,line_total REAL,unit TEXT NOT NULL DEFAULT 'PCS')");
        createV2Tables(db);
    }

    private void createV2Tables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,invoice_id INTEGER,amount REAL NOT NULL,mode TEXT NOT NULL,date_ms INTEGER NOT NULL,note TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,qty_delta REAL NOT NULL,unit TEXT NOT NULL DEFAULT 'PCS',movement_type TEXT NOT NULL,reference_id INTEGER,date_ms INTEGER NOT NULL,note TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS sales_returns(id INTEGER PRIMARY KEY AUTOINCREMENT,return_no TEXT UNIQUE,customer_id INTEGER,customer TEXT NOT NULL,date_ms INTEGER NOT NULL,reason TEXT NOT NULL,refund_mode TEXT NOT NULL DEFAULT 'CREDIT',total REAL NOT NULL DEFAULT 0,note TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS return_items(id INTEGER PRIMARY KEY AUTOINCREMENT,return_id INTEGER NOT NULL,product_id INTEGER,product_name TEXT NOT NULL,qty REAL NOT NULL,unit TEXT NOT NULL DEFAULT 'PCS',amount REAL NOT NULL DEFAULT 0,restock INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE IF NOT EXISTS app_settings(setting_key TEXT PRIMARY KEY,setting_value TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        if (oldVersion < 2) {
            addColumnIfMissing(db,"customers","opening_balance","REAL NOT NULL DEFAULT 0");
            addColumnIfMissing(db,"products","purchase_price","REAL NOT NULL DEFAULT 0");
            addColumnIfMissing(db,"products","unit","TEXT NOT NULL DEFAULT 'PCS'");
            addColumnIfMissing(db,"products","case_size","REAL NOT NULL DEFAULT 1");
            addColumnIfMissing(db,"products","hsn","TEXT");
            addColumnIfMissing(db,"invoices","invoice_type","TEXT NOT NULL DEFAULT 'GST'");
            addColumnIfMissing(db,"invoices","payment_mode","TEXT NOT NULL DEFAULT 'CREDIT'");
            addColumnIfMissing(db,"invoices","paid_amount","REAL NOT NULL DEFAULT 0");
            addColumnIfMissing(db,"invoices","payment_status","TEXT NOT NULL DEFAULT 'UNPAID'");
            addColumnIfMissing(db,"invoices","customer_id","INTEGER");
            addColumnIfMissing(db,"invoice_items","unit","TEXT NOT NULL DEFAULT 'PCS'");
            createV2Tables(db);
            db.execSQL("INSERT INTO stock_movements(product_id,qty_delta,unit,movement_type,date_ms,note) SELECT id,stock,'PCS','OPENING',strftime('%s','now')*1000,'Migrated opening stock' FROM products WHERE stock != 0");
        }
    }

    private void addColumnIfMissing(SQLiteDatabase db,String table,String column,String definition) {
        boolean exists=false;
        Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null);
        try { while(c.moveToNext()) if(column.equalsIgnoreCase(c.getString(1))) exists=true; }
        finally { c.close(); }
        if(!exists) db.execSQL("ALTER TABLE "+table+" ADD COLUMN "+column+" "+definition);
    }

    public long addCustomer(String name,String phone,String address) {
        ContentValues v=new ContentValues(); v.put("name",name);v.put("phone",phone);v.put("address",address);
        return getWritableDatabase().insert("customers",null,v);
    }
    public long addProduct(String name,String code,double price,double gst,double stock) {
        return addProduct(name,code,price,0,gst,stock,"PCS",1,null);
    }
    public long addProduct(String name,String code,double price,double purchasePrice,double gst,double stock,String unit,double caseSize,String hsn) {
        ContentValues v=new ContentValues();v.put("name",name);v.put("code",code);v.put("price",price);v.put("purchase_price",purchasePrice);v.put("gst",gst);v.put("stock",stock);v.put("unit",unit);v.put("case_size",caseSize);v.put("hsn",hsn);
        long id=getWritableDatabase().insert("products",null,v);
        if(id>0 && stock!=0) recordStockMovement(id,stock,unit,"OPENING",id,"Opening stock");
        return id;
    }
    public Cursor customers(){return getReadableDatabase().rawQuery("SELECT id,name,phone,address,opening_balance FROM customers ORDER BY name",null);}
    public Cursor products(){return getReadableDatabase().rawQuery("SELECT id,name,code,price,gst,stock,purchase_price,unit,case_size,hsn FROM products ORDER BY name",null);}
    public Cursor invoices(){return getReadableDatabase().rawQuery("SELECT id,invoice_no,customer,date_ms,subtotal,gst,total,invoice_type,payment_mode,paid_amount,payment_status FROM invoices ORDER BY date_ms DESC",null);}
    public double sales(){return scalar("SELECT COALESCE(SUM(total),0) FROM invoices",null);}
    public double stockValue(){return scalar("SELECT COALESCE(SUM(price*stock),0) FROM products",null);}
    public double weeklySales(){return scalar("SELECT COALESCE(SUM(total),0) FROM invoices WHERE date_ms>=?",new String[]{String.valueOf(System.currentTimeMillis()-7L*24*60*60*1000)});}
    public double outstanding(){return scalar("SELECT COALESCE(SUM(total-paid_amount),0) FROM invoices",null);}
    public double collections(){return scalar("SELECT COALESCE(SUM(amount),0) FROM payments",null);}
    public int customerCount(){return count("customers");}
    public int productCount(){return count("products");}
    private int count(String table){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
    private double scalar(String sql,String[] args){Cursor c=getReadableDatabase().rawQuery(sql,args);try{return c.moveToFirst()?c.getDouble(0):0;}finally{c.close();}}

    /** Atomic multi-line invoice: validates aggregate quantities, saves lines, updates stock and records payment. */
    public long saveInvoiceMulti(String invoiceNo,String customer,long customerId,long date,double subtotal,double gst,double total,
                                 String invoiceType,String paymentMode,double paid,ArrayList<InvoiceLine> lines) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            HashMap<Long,Double> requested=new HashMap<>();
            for(InvoiceLine line:lines){Double old=requested.get(line.productId);requested.put(line.productId,(old==null?0:old)+line.stockQuantity);}
            for(Map.Entry<Long,Double> e:requested.entrySet()){
                Cursor c=db.rawQuery("SELECT stock FROM products WHERE id=?",new String[]{String.valueOf(e.getKey())});
                boolean found=c.moveToFirst();double available=found?c.getDouble(0):0;c.close();
                if(!found || available+0.000001<e.getValue()) return -1;
            }
            ContentValues inv=new ContentValues();inv.put("invoice_no",invoiceNo);inv.put("customer",customer);inv.put("customer_id",customerId);inv.put("date_ms",date);inv.put("subtotal",subtotal);inv.put("gst",gst);inv.put("total",total);inv.put("invoice_type",invoiceType);inv.put("payment_mode",paymentMode);inv.put("paid_amount",paid);inv.put("payment_status",paid<=0?"UNPAID":paid+0.000001>=total?"PAID":"PARTIAL");
            long invoiceId=db.insertOrThrow("invoices",null,inv);
            for(InvoiceLine line:lines){
                ContentValues item=new ContentValues();item.put("invoice_id",invoiceId);item.put("product_id",line.productId);item.put("product_name",line.productName);item.put("qty",line.quantity);item.put("price",line.price);item.put("gst",line.gstRate);item.put("line_total",line.lineTotal);item.put("unit",line.unit);db.insertOrThrow("invoice_items",null,item);
                db.execSQL("UPDATE products SET stock=stock-? WHERE id=?",new Object[]{line.stockQuantity,line.productId});
                ContentValues movement=new ContentValues();movement.put("product_id",line.productId);movement.put("qty_delta",-line.stockQuantity);movement.put("unit",line.unit);movement.put("movement_type","SALE");movement.put("reference_id",invoiceId);movement.put("date_ms",date);movement.put("note",invoiceNo);db.insertOrThrow("stock_movements",null,movement);
            }
            if(paid>0){ContentValues p=new ContentValues();p.put("customer_id",customerId);p.put("invoice_id",invoiceId);p.put("amount",paid);p.put("mode",paymentMode);p.put("date_ms",date);p.put("note","Invoice payment "+invoiceNo);db.insertOrThrow("payments",null,p);}
            db.setTransactionSuccessful();return invoiceId;
        } catch(Exception e){return -1;} finally{db.endTransaction();}
    }

    public long saveInvoice(String invoiceNo,String customer,long date,double subtotal,double gst,double total,long productId,String productName,double qty,double price,double rate){
        ArrayList<InvoiceLine> lines=new ArrayList<>();lines.add(new InvoiceLine(productId,productName,qty,price,rate,total));
        return saveInvoiceMulti(invoiceNo,customer,-1,date,subtotal,gst,total,"GST","CREDIT",0,lines);
    }

    public boolean recordPayment(long customerId,long invoiceId,double amount,String mode,long date,String note){
        if(amount<=0)return false;SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            if(invoiceId>0){Cursor c=db.rawQuery("SELECT total,paid_amount FROM invoices WHERE id=?",new String[]{String.valueOf(invoiceId)});if(!c.moveToFirst()){c.close();return false;}double total=c.getDouble(0),paid=c.getDouble(1);c.close();if(amount>total-paid+0.000001)return false;ContentValues u=new ContentValues();u.put("paid_amount",paid+amount);u.put("payment_status",paid+amount+0.000001>=total?"PAID":"PARTIAL");db.update("invoices",u,"id=?",new String[]{String.valueOf(invoiceId)});}
            ContentValues p=new ContentValues();p.put("customer_id",customerId);p.put("invoice_id",invoiceId>0?invoiceId:null);p.put("amount",amount);p.put("mode",mode);p.put("date_ms",date);p.put("note",note);db.insertOrThrow("payments",null,p);db.setTransactionSuccessful();return true;
        }catch(Exception e){return false;}finally{db.endTransaction();}
    }

    /** Returns goods to stock only when restock=true; damaged/expired goods can be recorded without restocking. */
    public long saveReturn(String returnNo,long customerId,String customer,long date,String reason,String refundMode,String note,ArrayList<InvoiceLine> lines,boolean restock){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            double total=0;for(InvoiceLine line:lines)total+=line.lineTotal;
            ContentValues r=new ContentValues();r.put("return_no",returnNo);r.put("customer_id",customerId);r.put("customer",customer);r.put("date_ms",date);r.put("reason",reason);r.put("refund_mode",refundMode);r.put("total",total);r.put("note",note);long id=db.insertOrThrow("sales_returns",null,r);
            for(InvoiceLine line:lines){ContentValues ri=new ContentValues();ri.put("return_id",id);ri.put("product_id",line.productId);ri.put("product_name",line.productName);ri.put("qty",line.quantity);ri.put("unit",line.unit);ri.put("amount",line.lineTotal);ri.put("restock",restock?1:0);db.insertOrThrow("return_items",null,ri);if(restock&&line.productId>0){db.execSQL("UPDATE products SET stock=stock+? WHERE id=?",new Object[]{line.stockQuantity,line.productId});ContentValues m=new ContentValues();m.put("product_id",line.productId);m.put("qty_delta",line.stockQuantity);m.put("unit",line.unit);m.put("movement_type","SALES_RETURN");m.put("reference_id",id);m.put("date_ms",date);m.put("note",reason);db.insertOrThrow("stock_movements",null,m);}}
            db.setTransactionSuccessful();return id;
        }catch(Exception e){return -1;}finally{db.endTransaction();}
    }

    public void recordStockMovement(long productId,double delta,String unit,String type,long referenceId,String note){
        ContentValues m=new ContentValues();m.put("product_id",productId);m.put("qty_delta",delta);m.put("unit",unit);m.put("movement_type",type);m.put("reference_id",referenceId);m.put("date_ms",System.currentTimeMillis());m.put("note",note);getWritableDatabase().insert("stock_movements",null,m);
    }
    public Cursor outstandingInvoices(){return getReadableDatabase().rawQuery("SELECT id,invoice_no,customer,total-paid_amount AS balance FROM invoices WHERE total>paid_amount ORDER BY date_ms DESC",null);}
    public Cursor invoiceLines(long invoiceId){return getReadableDatabase().rawQuery("SELECT product_name,qty,price,gst,line_total,unit FROM invoice_items WHERE invoice_id=?",new String[]{String.valueOf(invoiceId)});}
    public Cursor customerLedger(long customerId){return getReadableDatabase().rawQuery("SELECT id,invoice_no,date_ms,total,paid_amount,payment_status FROM invoices WHERE customer_id=? ORDER BY date_ms DESC",new String[]{String.valueOf(customerId)});}
}
