# Shri Krishna Enterprise — Offline Billing App (Development v1.1)

Android Java app for a single Samsung phone, using a local SQLite database. Normal billing works offline. No server or subscription is required.

## Requirements incorporated in this development version

- Cash and credit sales, with cash / UPI / bank payment modes and partial amount received on an invoice.
- Multi-line invoices: add several products to one bill, calculate line totals and GST, validate combined stock, and deduct stock atomically.
- GST invoice and non-GST bill selection. Non-GST bills calculate no GST.
- Piece and case selling units, with a configured units-per-case conversion against the product's stock unit.
- Invoice-level outstanding balance and payment collection against an unpaid/part-paid invoice.
- Return entry for unsold, damaged and expiry goods, with an explicit stock-restock decision. Damaged/expiry goods are blocked from being returned to saleable stock in the simple return screen.
- Database schema v2 with a migration from v1. Existing v1 customers, products and invoices are preserved; new tables record payments, stock movements and returns.
- Database export and restore through Android's document picker. The picker can save to phone storage or a connected Google Drive provider, if available.

## Important limitations — do not treat this as certified accounting software

- This is a development build. It has not been compiled or tested on the user's Samsung phone or physical printer in this workspace.
- GST is a simple item-rate calculation. CGST/SGST/IGST place-of-supply treatment, GSTIN validation, HSN/SAC capture UI, e-invoicing/e-way bill, credit/debit notes and accountant-reviewed tax formatting are not implemented. Confirm tax treatment with an accountant before issuing statutory invoices.
- Customer name is currently typed on the invoice; invoice payments are tracked against the invoice, but a full customer-master-linked party ledger, opening balance workflow and supplier ledger are not complete.
- Purchase entry, supplier management, purchase returns, expenses, profit-and-loss, supplier dues and cash/bank reconciliation are not complete. Purchase price is captured for products but no purchase transaction updates stock yet.
- The simple returns screen records one product per return. It does not yet link a return to the original invoice, calculate/issue a refund, create a credit note, or reconcile customer balance. Restock choice must be based on physical inspection.
- Piece/case conversion is configured per product. Set the product's stock unit and units-per-case carefully; verify conversion and stock counts before live use.
- Invoice editing, invoice cancellation/void with reversal entries, returns against invoices, barcode scanning, batch/expiry lot tracking, route-wise delivery, crate tracking, and audit log are not complete.
- Backup and restore are manual. Export backups regularly to a safe location. Restore replaces the current database. Test a backup/restore cycle before relying on it. Do not uninstall or clear app data without a verified backup.
- Bluetooth Classic SPP printing remains basic and printer-specific. BLE-only printers may not work. 58mm/80mm width formatting, paper feed/cut, Unicode/Bengali printing and actual printer compatibility still require device tests.
- There is no multi-user sync, cloud database, role-based access or automatic scheduled backup.

## Build

The repository's GitHub Actions workflow can build a debug APK. Upload the contents of the project ZIP as expected by the existing workflow, then run the workflow from the Actions tab. On success, download the `Shri-Krishna-Enterprise-debug-APK` artifact and extract `app-debug.apk`.

## Safe rollout checklist

1. Install as an update only after confirming Android allows it to update the same application ID. Do not uninstall the current app.
2. Export a backup before updating; verify the backup file exists.
3. Test a multi-item invoice, same-product repeated rows, cash invoice, credit invoice, partial payment, non-GST bill, piece/case conversion and low-stock rejection.
4. Test return stock treatment for unsold, damaged and expiry goods.
5. Export and restore a backup on a test copy before using it for live records.
6. Test the exact 58mm/80mm printer model and inspect printed totals before relying on it.
